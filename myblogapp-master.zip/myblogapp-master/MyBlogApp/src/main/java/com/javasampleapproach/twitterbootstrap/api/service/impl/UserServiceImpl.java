package com.javasampleapproach.twitterbootstrap.api.service.impl;

import com.javasampleapproach.twitterbootstrap.model.User;
import com.javasampleapproach.twitterbootstrap.service.api.UserService;


public class UserServiceImpl implements UserService{

	@Override
	public User save(User entity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public User update(String id, User entity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public User get(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public User getUserByEmail(String email) {
		// TODO Auto-generated method stub
		return null;
	}

	
}

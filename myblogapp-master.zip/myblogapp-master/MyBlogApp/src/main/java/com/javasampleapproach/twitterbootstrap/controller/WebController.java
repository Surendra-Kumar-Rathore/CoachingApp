package com.javasampleapproach.twitterbootstrap.controller;


public class WebController {

	
	
}
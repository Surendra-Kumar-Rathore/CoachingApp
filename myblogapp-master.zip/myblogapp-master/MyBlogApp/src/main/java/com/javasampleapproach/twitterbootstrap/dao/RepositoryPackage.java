package com.javasampleapproach.twitterbootstrap.dao;

/**
 * //No-op marker interface used for component scanning 
 * @author Ashish Mishra
 *
 */
public interface RepositoryPackage {

}

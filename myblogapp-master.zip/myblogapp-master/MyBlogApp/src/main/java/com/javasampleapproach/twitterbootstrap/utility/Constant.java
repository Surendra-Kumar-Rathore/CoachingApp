package com.javasampleapproach.twitterbootstrap.utility;

public class Constant {

	public static String REAL_PATH = "C:/Users/as393082/Desktop/images";
}
